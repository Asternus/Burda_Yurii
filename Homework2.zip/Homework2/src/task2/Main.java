package task2;

import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        findArea();
        System.out.println();
        createNum();
        System.out.println();
        findEven();
        System.out.println();
        transBinary();
    }

    public static void findArea() {
        double a = 15.0;
        double b = 25.0;
        double c = 14.0;
        double p = (a + b + c) / 2.0;
        double s = Math.sqrt(p * (p - a) * (p - b) * (p - c));
        System.out.println("Площадь треугольника равна: " + s);
    }

    public static void createNum() {
        int rn1, rn2, rn3;
        Random x = new Random();
        rn1 = x.nextInt();
        rn2 = x.nextInt();
        rn3 = x.nextInt();
        int fewer = (Math.abs(rn1) < Math.abs(rn2) && Math.abs(rn1) < Math.abs(rn3)) ? rn1 : (Math.abs(rn2) < Math.abs(rn1) && Math.abs(rn2) < Math.abs(rn3)) ? rn2 : rn3;
        System.out.println("|Меньшее число| = " + fewer);
    }

    public static void findEven() {
        Random y = new Random();
        int even = (y.nextInt()) % 2;
        if (even == 0) {
            System.out.println("Число четное");
        } else {
            System.out.println("Число не четное");
        }
    }

    public static void transBinary() {
        System.out.println("Введите целое число (int) которое необходимо перевести из десятичного в двоичное:");
        Scanner first = new Scanner(System.in);
        int mod = first.nextInt();
        String binary = Integer.toBinaryString(mod);
        System.out.println("8 в двоичной системе = " + binary);
    }
}

