package question1;

public class Main {
    public static void main(String[] args) {
        transBinary(); // здесь вопросов нет, но можно ли так?
        binar(8); // вызвали метод с числом 8 который я нашел
        System.out.println();
        binar1(); // пытался создать но есть ошибся
    }

    public static void transBinary() {
        int mod = 8;
        String bynar = Integer.toBinaryString(mod);
        System.out.println("8 в двоичной системе = " + bynar);
    }

    public static void binar(int a) {
        int b; // вводим переменную b
        String temp = ""; // создаем пустую строку
        while (a != 0) {  // пишем наш цикл
            b = a % 2;  // ищем остаток (1 или 0)
            temp = b + temp; // не ясно? мы добавили к числу строку которую создали ранее?? Но вот на простом примере без цикла это у меня не сработало
            a = a / 2; // ищем целое от деления
        }
        System.out.print("Пример который я нашел но не понял = " + temp);  // вывод на экран
    }

    public static void binar1() { // это я осваиваю реверс
        int b; // создал число b
        int a = 8; // создал число a
        while (a > 0) {  // начал писать метод
            b = a % 2; // отстаток от деления (1 или 0)
            a /= 2; // отстаток от деления
            String str = Integer.toString(b); // перевел результат b в строку
            StringBuffer buffer = new StringBuffer(str); // воспользовался системой буфера, хотя можно и без него
            buffer.reverse(); // наш реверс
            System.out.print(buffer.reverse()); // облом - резульат не повернулся, попытка вывести переменную buffer завершилась точно так же
        }
    }
}
